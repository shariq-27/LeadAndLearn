<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "leadnlearn";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contactdata (name, email, phone, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $phone, $message);

    if ($stmt->execute()) {
        $success_message = "Your message has been sent successfully!";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Lead and Learn</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="contact.css">
    <link rel="shortcut icon" href="favicon_io/android-chrome-512x512.png" type="image/x-icon">
</head>

<body>
    <!-- Navbar (optional) -->
    <!-- Add your navbar here -->

    <!-- Hero Section -->
    <section class="container-fluid bg-dark text-white text-center py-5">
        <h1>Contact Us</h1>
    </section>

    <!-- Contact Section -->
    <div class="container my-5">
        <div class="row">
            <!-- Contact Info -->
            <div class="col-md-6">
                <h3>Get In Touch</h3>
                <p><strong>Lead and Learn Foundation</strong></p>
                <p>Panvel Branch: Lead and Learn Foundation, Shop 8,9,10,11, 1st floor, Omkar Arcade, <br>Opp. Panvel Railway station, Navi Mumbai 410206 </p>
                <p><i class="bi bi-telephone"></i>  +91 8657076759/9819549857
                </p>
                <p><i class="bi bi-envelope"></i> leadandlearn.in</p>
                <p>To apply, please send your CV to <a href="mailto:careers@leadandlearn.org">leadandlearnfoundation@gmail.com
                </a></p>
            </div>

            <!-- Contact Form -->
            <div class="col-md-6">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name *</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Full Name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone *</label>
                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Phone / Mobile Number" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="4" placeholder="Enter Your Message"></textarea>
                    </div>
                    <button type="submit" class="btn btn-warning w-100">Submit</button>
                </form>
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success mt-3" role="alert">
                        <?php echo $success_message; ?>
                    </div>
                <?php elseif (isset($error_message)): ?>
                    <div class="alert alert-danger mt-3" role="alert">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4">
        <p>&copy; 2024 Lead and Learn Foundation. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

<footer class="footer bg-dark text-white">
    <div class="container py-4">
        <div class="row">
            <!-- About Us Section -->
            <div class="col-md-2">
                <h5>About Us</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Legacy & Journey</a></li>
                    <li><a href="#" class="text-white">Our Team</a></li>
                    <li><a href="#" class="text-white">Awards & Accolades</a></li>
                    <li><a href="#" class="text-white">Annual Reports</a></li>
                    <li><a href="#" class="text-white">Testimonials</a></li>
                </ul>
            </div>
            <!-- What We Do Section -->
            <div class="col-md-2">
                <h5>Services</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Pre-Schools and Schools</a></li>
                    <li><a href="#" class="text-white">Workshops</a></li>
                    <li><a href="#" class="text-white">Counselling & EDP</a></li>
                    <li><a href="#" class="text-white">Community Outreach</a></li>
                </ul>
            </div>
            <!-- Get Involved Section -->
            <div class="col-md-2">
                <h5>Get Involved</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Volunteer With Us</a></li>
                    <li><a href="#" class="text-white">Career With Us</a></li>
                    <li><a href="#" class="text-white">Donate</a></li>
                    <li><a href="#" class="text-white">Success Stories</a></li>
                </ul>
            </div>
            <!-- Media Hub Section -->
            <div class="col-md-2">
                <h5>Impact</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Blog</a></li>
                    <li><a href="#" class="text-white">Events</a></li>
                    <li><a href="#" class="text-white">Media Coverage</a></li>
                    <li><a href="#" class="text-white">Gallery</a></li>
                </ul>
            </div>
            <!-- Contact Section -->
            <div class="col-md-4">                
                <h5>Contact Us</h5>
                <p><a href="tel:+918283701013" class="text-white"><i class="fa fa-phone"></i> +91 8283701013</a></p>
                <p><a href="tel:+918287059198" class="text-white"><i class="fa fa-phone"></i> +91 8287059198</a></p>
                <p><a href="mailto:info@leadandlearn.in" class="btn btn-warning btn-sm text-dark">Email Us</a></p>
                <p><a href="#" class="btn btn-warning btn-sm text-dark">Donate Now</a></p>
            </div>
        </div>
        <div class="text-center mt-3">
            <p class="small">&copy; 2024 Lead and Learn. All rights reserved. <a href="#" class="text-white">Privacy Policy</a></p>
        </div>
    </div>
</footer>

</html>
