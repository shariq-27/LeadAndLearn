<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "leadnlearn";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a new record to impact or success_stories table
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "add") {
    $table = $_POST['table']; // Get table name
    $title = $_POST["title"];
    $description = $_POST["description"];
    $target_dir = $table . "/";

    // Create directory if it doesn't exist
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Handle file upload
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file is an actual image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false && $_FILES["image"]["size"] <= 5000000) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Insert into the specified table
            $sql = "INSERT INTO $table (image, title, description) VALUES ('$target_file', '$title', '$description')";
            if ($conn->query($sql) === TRUE) {
                echo "<p>Record added to $table successfully!</p>";
            } else {
                echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
            }
        } else {
            echo "<p>Error uploading file.</p>";
        }
    } else {
        echo "<p>File is not an image or is too large.</p>";
    }
}

// Handle deletion of a record from impact or success_stories table
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "delete") {
    $table = $_POST['table'];
    $id = $_POST["id"];

    // Fetch and delete the image file
    $img_query = "SELECT image FROM $table WHERE id = $id";
    $img_result = $conn->query($img_query);
    if ($img_result->num_rows > 0) {
        $img_row = $img_result->fetch_assoc();
        unlink($img_row['image']);
    }

    // Delete the record from the specified table
    $sql = "DELETE FROM $table WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Record deleted from $table successfully!</p>";
    } else {
        echo "<p>Error deleting record: " . $conn->error . "</p>";
    }
}

// Fetch all records from impact table
$impact_records = $conn->query("SELECT * FROM impact");

// Fetch all records from success_stories table
$success_stories_records = $conn->query("SELECT * FROM success_stories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Management</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; display: flex; flex-direction: column; align-items: center; }
        .container { width: 80%; max-width: 600px; padding: 20px; background-color: #ffffff; border: 2px solid #008080; border-radius: 8px; margin-top: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        h2 { color: #008080; text-align: center; }
        label { font-weight: bold; color: #008080; display: block; margin-top: 10px; }
        input[type="text"], input[type="file"], textarea { width: 100%; padding: 8px; margin-top: 5px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background-color: #008080; color: #ffffff; font-weight: bold; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px; }
        button:hover { background-color: #FFA500; }
        .record-list { margin-top: 30px; }
        .record { display: flex; align-items: center; justify-content: space-between; padding: 10px; border-bottom: 1px solid #ddd; }
        .record img { width: 50px; height: 50px; object-fit: cover; border-radius: 5px; }
        .record-details { flex: 1; margin-left: 10px; }
        .delete-button { background-color: #FFA500; color: #ffffff; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer; }
        .delete-button:hover { background-color: #cc6600; }
    </style>
</head>
<body>

<div class="container">
    <h2>Insert Impact Data</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="table" value="impact">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="3" required></textarea>
        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required>
        <button type="submit">Submit</button>
    </form>
</div>

<div class="container">
    <h2>Insert Success Story</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="table" value="success_stories">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="3" required></textarea>
        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required>
        <button type="submit">Submit</button>
    </form>
</div>

<div class="container record-list">
    <h2>Existing Impact Records</h2>
    <?php if ($impact_records->num_rows > 0): ?>
        <?php while($row = $impact_records->fetch_assoc()): ?>
            <div class="record">
                <img src="<?php echo $row['image']; ?>" alt="Image">
                <div class="record-details">
                    <h3><?php echo $row['title']; ?></h3>
                    <p><?php echo $row['description']; ?></p>
                </div>
                <form action="" method="POST">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="table" value="impact">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" class="delete-button">Delete</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No impact records found.</p>
    <?php endif; ?>
</div>

<div class="container record-list">
    <h2>Existing Success Stories</h2>
    <?php if ($success_stories_records->num_rows > 0): ?>
        <?php while($row = $success_stories_records->fetch_assoc()): ?>
            <div class="record">
                <img src="<?php echo $row['image']; ?>" alt="Image">
                <div class="record-details">
                    <h3><?php echo $row['title']; ?></h3>
                    <p><?php echo $row['description']; ?></p>
                </div>
                <form action="" method="POST">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="table" value="success_stories">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" class="delete-button">Delete</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No success stories found.</p>
    <?php endif; ?>
</div>

</body>
</html>

<?php
$conn->close();
?>
