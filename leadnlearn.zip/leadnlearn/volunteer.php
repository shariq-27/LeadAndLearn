<?php
$servername = "localhost"; // Your server name
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "leadnlearn"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize a variable to hold success message
$successMessage = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO volunteer_data (name, email, phone, expertise_field, reason_of_volunteering) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $field, $message);

    // Set parameters
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $field = $_POST['field'];
    $message = $_POST['message'];

    // Execute the statement
    if ($stmt->execute()) {
        $successMessage = "Thank you for your interest in volunteering! We will contact you soon.";
    } else {
        $successMessage = "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer With Us - LeadAndLearn</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="volunteer.css">
    <link rel="shortcut icon" href="favicon_io/android-chrome-512x512.png" type="image/x-icon">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light Mynav">
        <div class="container-fluid">
            <div class="logo-container d-flex align-items-center">
                <img class="navbar-brand logo" src="/images/logo.png" alt="logo" />
                <div>
                    <h1 class="logo-text">LEAD AND LEARN <span class="d-flex justify-content-center">FOUNDATION</span></h1>
                </div>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse nav-component" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
                    <li class="nav-item">
                        <a class="nav-link nav-link-color" aria-current="page" href="index.html">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle nav-link-color" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="LeadershipBehindLLF.html">Leadership Behind LLF</a></li>
                            <li><a class="dropdown-item" href="testimonials.html">Testimonials</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle nav-link-color" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Services</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item fw-bold" href="#">Skill Training</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="pre-school-and-schools.html">Pre-School And Schools</a></li>
                            <li><a class="dropdown-item" href="adult-scales.html">Adult Scales</a></li>
                            <li><a class="dropdown-item" href="adult.html">Adults</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle nav-link-color" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Impact</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="impact.html">Success Stories</a></li>
                            <li><a class="dropdown-item" href="#">Partners</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle nav-link-color" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Get Involved</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Volunteer With Us</a></li>
                            <li><a class="dropdown-item" href="#">CSR</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nav-link-color" aria-current="page" href="#">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nav-link-color" aria-current="page" href="#"><button type="button" class="btn custom-btn">Donate</button></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-section bg-primary text-white text-center py-5">
        <h1>Volunteer With Us</h1>
        <p>Join us in making a difference in the lives of thousands of students and communities.</p>
    </div>

    <section class="container my-5">
        <h2 class="text-center mb-4">Why Volunteer with Lead And Learn?</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="images/impactful.png" class="card-img-top" alt="Make an Impact">
                    <div class="card-body">
                        <h5 class="card-title">Make an Impact</h5>
                        <p class="card-text">Help us bring essential life skills to students across various age groups. Your contribution can change lives.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="images/community.png" class="card-img-top" alt="Build a Community">
                    <div class="card-body">
                        <h5 class="card-title">Build a Community</h5>
                        <p class="card-text">Meet like-minded individuals who are passionate about education and community development.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="images/growth.png" class="card-img-top" alt="Personal Growth">
                    <div class="card-body">
                        <h5 class="card-title">Personal Growth</h5>
                        <p class="card-text">Gain new skills, enhance your resume, and grow personally by contributing to a meaningful cause.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="container my-5">
        <h2 class="text-center mb-4">Join Us as a Volunteer</h2>
        <?php if ($successMessage): ?>
            <div class="alert alert-success" role="alert">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        <form action="volunteer.php" method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
            </div>
            <div class="mb-3">
                <label for="field" class="form-label">Area of Expertise</label>
                <input type="text" class="form-control" id="field" name="field" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Reason for Volunteering</label>
                <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </section>

    <footer class="bg-dark text-white text-center py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-2">
                    <h5>About Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Our Mission</a></li>
                        <li><a href="#" class="text-white">Our Vision</a></li>
                        <li><a href="#" class="text-white">Team</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>Programs</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">After School</a></li>
                        <li><a href="#" class="text-white">Community Projects</a></li>
                        <li><a href="#" class="text-white">Skill Development</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>Get Involved</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Volunteer</a></li>
                        <li><a href="#" class="text-white">Donations</a></li>
                        <li><a href="#" class="text-white">Partnerships</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>Contact</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Contact Us</a></li>
                        <li><a href="#" class="text-white">FAQs</a></li>
                        <li><a href="#" class="text-white">Feedback</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>Follow Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Facebook</a></li>
                        <li><a href="#" class="text-white">Twitter</a></li>
                        <li><a href="#" class="text-white">Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-e1vC/xp2E5HQhi6jA4blPtZk1JZo26Z8Yp/9IfT6ZT4c53UwoKnST7zrrBvRO7jp" crossorigin="anonymous"></script>
</body>

</html>
